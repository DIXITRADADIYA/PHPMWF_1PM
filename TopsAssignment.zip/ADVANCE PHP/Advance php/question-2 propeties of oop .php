What Are Properties Of Object Oriented Systems?

=> 1. class
   2. object
   3. inheritance
   4. polymerphisam
   5. abstraction
   6. encapsutation

  