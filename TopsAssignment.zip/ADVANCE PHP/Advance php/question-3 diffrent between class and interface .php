Class	Interface
o	The keyword used to create a class is “class”	
o=>	The keyword used to create an interface is “interface”

o	A class can be instantiated i.e, objects of a class can be created.	
o=>	An Interface cannot be instantiated i.e, objects cannot be created.

o	Classes does not support multiple inheritance.	
o=> Interface supports multiple inheritance.

o	It can be inherit another class.	
o=>	It cannot inherit a class.


o	It can be inherited by another class using the keyword ‘extends’.	
o=> It can be inherited by a class by using the keyword ‘implements’ and it can be inherited by an interface using the keyword ‘extends’.


o	It cannot contain abstract methods.	
o=>	It contains abstract methods only.
