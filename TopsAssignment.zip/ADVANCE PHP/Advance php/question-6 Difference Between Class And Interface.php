=>Interface Class	
o>xAbstract Class


=>Interface class supports multiple inheritance feature
o>Abstract class does not support multiple inheritances.

=>This does not contain a data member.
o>Abstract class does contain a data member.

=>The interface does not allow containers.	
o>The abstract class supports containers.

=>An interface class only contains incomplete members which refer to the signature of the member
o>Abstract class contains both incomplete(i.e. abstract) and complete members.

=>Since everything is assumed to be public, an interface class does not have access modifiers by default.
o>An abstract class can contain access modifiers within subs, functions, and properties.

=>Any member of an interface cannot be static.	
o>Only a complete member of the abstract class can be static.
