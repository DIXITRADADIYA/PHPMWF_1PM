
<ul id='nav_1'>
    <li>t1</li>
    <li>t2</li>
    <li>t3</li>
</ul>

<script>
    let lis = document.getElementById('nav_1').getElementsByTagName('li');
    console.log(lis);
</script>

