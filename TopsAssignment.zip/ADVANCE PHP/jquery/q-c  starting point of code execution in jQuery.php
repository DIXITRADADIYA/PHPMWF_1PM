c) Which is the starting point of code execution in jQuery?
=>$(document). ready() function