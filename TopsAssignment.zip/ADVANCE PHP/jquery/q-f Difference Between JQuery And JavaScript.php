f) Explain Difference Between JQuery And JavaScript?
=>jQuery	JavaScript

It is a javascript library.
It is a dynamic and interpreted web-development programming language.


The user only need to write the required jQuery code	
The user needs to write the complete js code


It is less time-consuming.	
It is more time consuming as the whole script is written.


There is no requirement for handling multi-browser compatibility issues.	
Developers develop their own code for handling multi-browser compatibility.


It is required to include the URL of the jQuery library in the header of the page.
JavaScript is supportable on every browser. Any additional plugin need not to be included.


It depends on the JavaScript as it is a library of js.	
jQuery is a part of javascript. Thus, the js code may or may not depend on jQuery.


It contains only a few lines of code.	
The code can be complicated, as well as long.


It is quite an easy, simple, and fast approach.	
It is a weakly typed programming approach.



jQuery is an optimized technique for web designing.
JavaScript is one of the popular web designing programming languages for developers that introduced jQuery.


jQuery creates DOM faster.	
JavaScript is slow in creating DOM.