 <?php
$arr=array('10','11','10','12','10','13');
print_r($arr);
echo"<br><br>";
print_r(array_rand($arr));
?>
    